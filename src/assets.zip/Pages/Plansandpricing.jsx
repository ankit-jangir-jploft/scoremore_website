
import {Button, Card, Col, Row} from 'react-bootstrap';
import Sidebar from '../Components/Sidebar';    
import Nextnn from "../assets/img/right-tk.svg";

const Plansandpricing = () => {
    return (
            <>
            <div className='dashboard-pg'>
                <div className='hdr-bgs'></div>
                <div className='container inr-pg-con'>  
                    <Row>
                        <Col sm={3}>
                            <Sidebar/>
                        </Col>  
                        <Col sm={9} className='rev-rslt '>
                            <div className='pln-prc'>
                                <h2>Take the First Step Towards Success!</h2>
                                <ul>
                                    <li><img src={Nextnn} alt="Right" /> Step-by-Step guide to PASS the NREMT Exam</li>    
                                    <li><img src={Nextnn} alt="Right" /> Self-paced Learning with 24/7 Access</li>    
                                    <li><img src={Nextnn} alt="Right" /> 1000+ Practice Questions </li>    
                                    <li><img src={Nextnn} alt="Right" /> 1000+ Digital Flashcards </li>    
                                    <li><img src={Nextnn} alt="Right" /> Detailed Performance Analytics</li>
                                    <li><img src={Nextnn} alt="Right" /> Multiple Readiness Tests</li>    
                                </ul>
                                <h3>PLUS Membership</h3>
                                <Card>
                                    <div className='month-prc'>
                                        1 Month<span>$12.99 billed monthly</span>
                                    </div>
                                    <p>$12.99 /mo</p>
                                </Card>
                                <Card>
                                    <div className='month-prc'>
                                        3 Months<span>$29.97 billed every 3 months</span>
                                    </div>
                                    <p>$9.99 /mo<small>Save 23%</small></p>
                                </Card> 
                                <Card>
                                    <div className='month-prc'>
                                        12 Months<span>$95.99 billed annually</span>
                                    </div>
                                    <p>$7.99 /mo<small>Save 38%</small></p>
                                </Card>
                                <Row>
                                    <Col md={12} className='text-center'>
                                        <Button className='btn-primary px-5'>Continue</Button>
                                    </Col>
                            </Row>   
                            </div>                      
                        </Col>
                    </Row>    
                </div>           
            </div>        
            </>             
  )
}
export default Plansandpricing;
