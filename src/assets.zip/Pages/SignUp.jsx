import React from 'react';
import { Button, Col, Form, Row } from 'react-bootstrap';
import Brand from "../assets/img/score-logo.svg";
import LoginImg from "../assets/img/mobile-hand.svg";
import { Link } from 'react-router-dom';

const SignUp = () => {
    return (
        <div className='logn-pge'>
            <Row>
                <Col md={6}>
                <img src={Brand} alt="Search" />
                    <div className='logn-pge-out'>
                        <div className='logn-pge-in'>
                            <h1>Sign Up</h1>
                            <p>Hi Welcome back, you.ve been missed</p>
                            <Form>
                                <Form.Group className="mb-3">
                                    <Form.Control type="text" placeholder="First Name" />
                                </Form.Group>
                                <Form.Group className="mb-3">
                                    <Form.Control type="text" placeholder="Last Name" />
                                </Form.Group>
                                <Form.Group className="mb-3" controlId="formGroupEmail">
                                    <Form.Control type="email" placeholder="Email ID" />
                                </Form.Group>
                                <Form.Group className="mb-3" controlId="formGroupPassword">
                                    <Form.Control type="password" placeholder="New password" />
                                </Form.Group>
                                <Form.Group className="mb-3" controlId="formGroupPassword">
                                    <Form.Control type="password" placeholder="New password" />
                                </Form.Group>
                                <Form.Group className="mb-3" id="formGridCheckbox">
                                    <Form.Check type="checkbox" label="By signing up you agree to our Privacy policy and Terms & conditions." />
                                </Form.Group>
                            </Form>
                            <Button className='btn-primary px-5'>Sign Up</Button>
                            <div className='sgn-link'>Already have an account? <Link to='/'>Sign In</Link></div>
                        </div>
                    </div>

                </Col>
                <Col md={6}>
                    <div className='lgn-rgt'>
                        <img src={LoginImg} alt="Image" />
                    </div>
                </Col>
            </Row>
            
        </div>
    );
}

export default SignUp;
