import React, { useEffect, useRef } from 'react';
import { Button, Card, Col, Container, Form, Row } from 'react-bootstrap';
import { A11y, Navigation, Pagination, Scrollbar } from 'swiper/modules';
import { SwiperSlide, Swiper } from 'swiper/react';
import Checmark from "../assets/img/checkmark.svg";
import GooglePlay from "../assets/img/google-play.svg"
import BestTutor from "../assets/img/bst-tutor.svg"
import Flexible from "../assets/img/flexible.svg"
import EasyAccess from "../assets/img/easyaccess.svg"
import Learning from "../assets/img/icn-set.svg"
import Test from "../assets/img/test1.png"
import Test1 from "../assets/img/test2.png"
import Test2 from "../assets/img/test3.png"
import Accordian from '../Components/Accordian';
import Footer from '../Components/Footer';

const Home = () => {
    const paginationRef = useRef(null);
    useEffect(() => {
        // This runs after the component has mounted, ensuring the pagination container exists
        if (paginationRef.current) {
          paginationRef.current.classList.add('custom-pagination'); // Ensure class is added
        }
      }, []);   
    return (
        <div className='hoe'>
            <div className='hero'>
                <Container>
                    <h1 className='text-center'>
                    Get better grades with the <br/>
                    #1 learning platform
                    </h1>
                    <p className='text-center mt-4'>
                        <img src={Checmark} alt="Checmark" /> Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    </p>
                    <p className='text-center'>
                        <img src={Checmark} alt="Checmark" /> In id est mollis, convallis diam eu, malesuada odio.
                    </p>
                    <div className='d-flex justify-content-center align-items-center mt-5'>
                        <a href='' className='btn-primary py-3 me-4'>Register for FREE</a>
                        <a href='' className=''><img src={GooglePlay} alt="GooglePlay" /></a>
                    </div>
                </Container>
            </div>
            
            <Row className='ftrs-sld'>
                <Col md={5} className='sl-lft'>
                    <h2>Our Features<br/>
                    Special For You</h2>
                    <p>We provide various special features <br/>
                    for all of you</p>
                    <div ref={paginationRef} className="custom-pagination"></div>

                </Col>
                <Col md={7}>
                    <Swiper
                    // install Swiper modules
                    modules={[Navigation, Pagination, Scrollbar, A11y]}
                    loop={true}
                    spaceBetween={50}
                    slidesPerView={3}
                    navigation
                    onInit={(swiper) => {
                        swiper.params.pagination.el = paginationRef.current;
                        swiper.pagination.init();
                        swiper.pagination.render();
                        swiper.pagination.update();
                      }}
                      breakpoints={{
                        375: {
                            width: 375,
                            slidesPerView: 1,
                          },
                        576: {
                          width: 576,
                          slidesPerView: 1,
                        },
                        1200: {
                          width: 1200,
                          slidesPerView: 3,
                        },
                      }}                      
                    scrollbar={{ draggable: true }}
                    onSwiper={(swiper) => console.log(swiper)}
                    onSlideChange={() => console.log('slide change')}
                    >
                    <SwiperSlide>
                        <div className='sl-img'><img src={BestTutor} alt="Best Tutor" /></div>
                        <h3>Best Tutors</h3>
                        <span>Bring your design <br/>vision to life in clean, <br/>semantic HTML5</span>
                    </SwiperSlide>
                    <SwiperSlide>
                    <div className='sl-img'><img src={Flexible} alt="Flexible" /></div>
                        <h3>Flexible</h3>
                        <span>Connect your <br/>marketing tools with <br/>built-in integrations</span>
                    </SwiperSlide>
                    <SwiperSlide>
                    <div className='sl-img'><img src={EasyAccess} alt="Easy Access" /></div>
                        <h3>Easy Access</h3>
                        <span>Connect your <br/>marketing tools with <br/>built-in integrations</span>
                    </SwiperSlide>
                    <SwiperSlide>
                        <div className='sl-img'><img src={BestTutor} alt="Best Tutor" /></div>
                        <h3>Best Tutors</h3>
                        <span>Bring your design <br/>vision to life in clean, <br/>semantic HTML5</span>
                    </SwiperSlide>

                    
                    </Swiper>
                </Col>
            </Row>
            <div className='lerng-jurn'>
                    <Container>
                        <Row>
                            <Col md={7}>
                            <h2>Let’ checkout your <br/><span>learning</span>  journey</h2>
                            </Col>
                            <Col md={5}></Col>
                        </Row>
                        <Row>
                            <Col md={7}>                                
                                <Row>
                                    <Col md={6} className='mt-5'>
                                        <div className='ttl-num'>1 <span></span></div>
                                        <h3>Choose your subject</h3>
                                        <p>Choose your favourite subject from the vast selection of subjects and continnue your journey</p>
                                    </Col>
                                    <Col md={6} className='mt-5'>
                                        <div className='ttl-num'>2 <span></span></div>
                                        <h3>Select the difficulty</h3>
                                        <p>Select difficulty of your choice and get the difficulty of questions according to your difficulty</p>
                                    </Col>
                                    <Col md={6} className='mt-5'>
                                        <div className='ttl-num'>3 <span></span></div>
                                        <h3>Increasing difficulty</h3>
                                        <p>Difficulty of questions will increase for the upcoming question irrespective of result of a previous question</p>
                                    </Col>
                                    <Col md={6} className='mt-5'>
                                        <div className='ttl-num'>4 <span></span></div>
                                        <h3>Detailed overview of scores</h3>
                                        <p>Get the detailed overview of your question answer session and tips on how you can improve</p>
                                    </Col>
                                </Row>
                            </Col>
                            <Col md={5} className='text-center'><img src={Learning} alt="Learning" /></Col>
                        </Row>
                    </Container>
            </div>

            <Container className='faq-sec'>
                     <h2>Common questions</h2> 
                      <Accordian/>

                <div className='testi-man'>
                      <h3>What people say about us</h3>
                      <p>With lots of unique blocks, you can easily build a page without <br/>coding. Build your next landing page.</p>
                      <Row>
                        <Col md={4}>
                            <Card>
                                <img src={Test} alt="Image" className='img-fluid' />
                                <p>“You made it so simple. My new site is so much faster and easier to work with than my old site.”</p>
                                <h4>Isabella Chavez <span>Graphic Designer</span></h4>
                            </Card>
                        </Col>
                        <Col md={4}>
                            <Card>
                                <img src={Test1} alt="Image" className='img-fluid' />
                                <p>“Simply the best. Better than all the rest. I’d recommend this product to beginners and advanced users.”</p>
                                <h4>Curtis Rhodes <span>Digital Marketer</span></h4>
                            </Card>
                        </Col>
                        <Col md={4}>
                            <Card>
                                <img src={Test2} alt="Image" className='img-fluid' />
                                <p>“Must have book for all, who want to be Product Designer or Interaction Designer.”</p>
                                <h4>Lucas Mann <span>Co Founder</span></h4>
                            </Card>
                        </Col>
                      </Row>
                </div>

                <div className='contct-frm'>
                      <Row>
                        <Col md="3">
                            <div className='contct-info'>
                                Call us
                                <span>+1-940-394-2948</span>
                                <span>+1-389-385-3807</span>
                            </div>
                            <div className='contct-info'>
                                Email us
                                <span>support@scoremore.com</span>
                                <span>contact@scoremore.com</span>
                            </div>
                            <div className='contct-info'>
                                Visit us
                                <span>34 Madison Street,<br/>
                                NY, USA 10005</span>
                            </div>
                        </Col>
                        <Col md="9">
                        <Form>
                            <Row>
                                <Col md={6}>
                                    <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                        <Form.Label>First & Last Name</Form.Label>
                                        <Form.Control type="text" placeholder="i.e. John Doe" />
                                    </Form.Group>
                                </Col>
                                <Col md={6}>
                                    <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                        <Form.Label>Email</Form.Label>
                                        <Form.Control type="email" placeholder="i.e. john@mail.com" />
                                    </Form.Group>
                                </Col>
                                <Col md={6}>
                                    <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                        <Form.Label>Phone Number</Form.Label>
                                        <Form.Control type="text" placeholder="i.e. +1-234-567-7890" />
                                    </Form.Group>
                                </Col>
                                <Col md={6}>
                                    <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                        <Form.Label>Subject</Form.Label>
                                        <Form.Control type="email" placeholder="i.e. I need a help" />
                                    </Form.Group>
                                </Col>
                                <Col md={12}>
                                    <Form.Group className="mb-3" controlId="exampleForm.ControlTextarea1">
                                        <Form.Label>Message</Form.Label>
                                        <Form.Control as="textarea" rows={3} />
                                    </Form.Group>
                                </Col>
                            </Row>                      
                            <Button className='btn-primary px-5'>Send</Button>
                        </Form>
                        </Col>
                      </Row>
                </div>

            </Container>

            <Footer/>

        </div>
    );
}

export default Home;
