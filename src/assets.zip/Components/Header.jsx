import React from 'react';
import { Button, Container, Nav, Navbar } from 'react-bootstrap';
import Brand from "../assets/img/score-logo.svg";

const Header = () => {
    return (
        <div>
            <Navbar expand="lg" className="">
            <Container>
                <Navbar.Brand href="#home"><img src={Brand} alt="Search" /></Navbar.Brand>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav" className='justify-content-end'>
                <Nav className="">
                    <Nav.Link href="#home">Home</Nav.Link>
                    <Nav.Link href="#link">Daily Challenge</Nav.Link>
                    <Nav.Link href="#link">Readiness Test</Nav.Link>
                    <Nav.Link href="/Login">Login</Nav.Link>                    
                </Nav>
                <Button type="submit">Sign Up</Button>
                </Navbar.Collapse>
            </Container>
            </Navbar>
        </div>
    );
}

export default Header;
