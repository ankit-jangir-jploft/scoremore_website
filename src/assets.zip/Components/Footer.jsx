import React from 'react';
import { Col, Container, ListGroup, Row } from 'react-bootstrap';
import LogoFooter from "../assets/img/logo-footer.svg";
import Facebook from "../assets/img/facebook.svg"
import Twitter from "../assets/img/twitter.svg"
import Instagram from "../assets/img/instagram.svg"
import { Link } from 'react-router-dom';


const Footer = () => {
    return (
        <div>
            <Container>
                <footer>
                    <Row>
                        <Col>
                            <img src={LogoFooter} alt="Logo" />
                            <p>20 Osgood Rd, Milford, NH 03055, USA
                            +1283871239190213021</p>
                        </Col>
                        <Col>
                            <h4>Company</h4>
                            <ListGroup>
                                <ListGroup.Item><Link to="/">Careers</Link></ListGroup.Item>
                                <ListGroup.Item><Link to="/">Teachers</Link></ListGroup.Item>
                                <ListGroup.Item><Link to="/">Support</Link></ListGroup.Item>
                                <ListGroup.Item><Link to="/">Contact</Link></ListGroup.Item>
                            </ListGroup>
                        </Col>
                        <Col>
                            <h4>Product</h4>
                            <ListGroup>
                                <ListGroup.Item><Link to="/">Courses</Link></ListGroup.Item>
                                <ListGroup.Item><Link to="/">Pricing</Link></ListGroup.Item>
                                <ListGroup.Item><Link to="/">Blog</Link></ListGroup.Item>
                            </ListGroup>
                        </Col>
                        <Col>
                            <h4>Legal</h4>
                            <ListGroup>
                                <ListGroup.Item><Link to="/">Terms & Conditions</Link></ListGroup.Item>
                                <ListGroup.Item><Link to="/">Privacy policy</Link></ListGroup.Item>
                            </ListGroup>
                        </Col>
                        <Col>
                            <a href=''>
                                <img src={Facebook} alt="Social" />
                            </a>
                            <a href=''>
                                <img src={Twitter} alt="Social" />
                            </a>
                            <a href=''>
                                <img src={Instagram} alt="Social" />
                            </a>
                        </Col>
                    </Row>
                </footer>
            </Container>
        </div>
    );
}

export default Footer;
