export const api_baseURL = "http://localhost:4748/api/v1";
// export const api_baseURL = "http://v4.checkprojectstatus.com:4748/api/v1"



//for img
// export const api_img_url = "http://v4.checkprojectstatus.com:4748"
export const api_img_url = "http://localhost:4748"